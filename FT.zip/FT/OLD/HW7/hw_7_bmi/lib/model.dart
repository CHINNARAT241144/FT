class Model {
  final String id;
  final String name;
  final double weight;
  final double height;
  final String address;
  final String email;

  Model._({
    required this.id,
    required this.name,
    required this.weight,
    required this.height,
    required this.address,
    required this.email,
  });

  factory Model.fromJson(Map<String, dynamic> json) {
    return Model._(
      id: json['id'],
      name: json['name'],
      weight: json['weight'].toDouble(),
      height: json['height'].toDouble(),
      address: json['address'],
      email: json['email'],
    );
  }
}
