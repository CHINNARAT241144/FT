// Updated: แสดง GPA เฉพาะรายบุคคลเมื่อมีการค้นหา พร้อมแสดงชื่อ + รหัสให้ถูกต้อง และเอา GPA รวมออก
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() => runApp(const ShowGrades());

class ShowGrades extends StatefulWidget {
  const ShowGrades({super.key});

  @override
  State<ShowGrades> createState() => _ShowGradesState();
}

class _ShowGradesState extends State<ShowGrades> {
  List list = [];
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _majorController = TextEditingController();
  final TextEditingController _studentIdController = TextEditingController();
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _creditController = TextEditingController();
  final TextEditingController _gradeController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  String? _searchStudentId;
  int? editingId;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    var response = await http.get(
      Uri.http('192.168.1.106:5000', 'grades'),
      headers: {"Accept": "application/json"},
    );
    setState(() {
      list = jsonDecode(response.body);
    });
  }

  double calculateGPA(List records) {
    double totalCredits = 0;
    double totalGradePoints = 0;
    for (var record in records) {
      int credit = int.tryParse(record['credit'].toString()) ?? 0;
      double gradePoint = _gradeToPoint(record['grade'].toString());
      totalCredits += credit;
      totalGradePoints += credit * gradePoint;
    }
    return totalCredits == 0 ? 0.0 : totalGradePoints / totalCredits;
  }

  double _gradeToPoint(String grade) {
    switch (grade.toUpperCase()) {
      case 'A': return 4.0;
      case 'B+': return 3.5;
      case 'B': return 3.0;
      case 'C+': return 2.5;
      case 'C': return 2.0;
      case 'D+': return 1.5;
      case 'D': return 1.0;
      case 'F': return 0.0;
      default: return 0.0;
    }
  }

  @override
  Widget build(BuildContext context) {
    List filteredList = _searchStudentId == null
        ? list
        : list.where((e) => e['studentId'] == _searchStudentId).toList();
    double gpa = calculateGPA(filteredList);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ระบบคำนวณเกรดเฉลี่ย (GPA)'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(labelText: 'ค้นหารหัสนักศึกษา'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () {
                    setState(() {
                      _searchStudentId = _searchController.text.trim();
                    });
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchStudentId = null;
                    });
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredList.length,
              itemBuilder: (context, index) {
                var item = filteredList[index];
                return Card(
                  child: ListTile(
                    title: Text('${item['name']} (${item['studentId']})'),
                    subtitle: Text('สาขา: ${item['major']}\nวิชา: ${item['subject']} หน่วยกิต: ${item['credit']} เกรด: ${item['grade']}'),
                    trailing: Wrap(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.green),
                          onPressed: () => _showEditDialog(item),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteData(item['id']),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          if (_searchStudentId != null)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                filteredList.isNotEmpty
                    ? 'GPA ของนักศึกษา ${filteredList[0]['name']} (${_searchStudentId}): ${gpa.toStringAsFixed(2)}'
                    : 'ไม่พบข้อมูลของรหัส $_searchStudentId',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: _showAddDialog,
      ),
    );
  }

  Future<void> _showAddDialog() async {
    editingId = null;
    _nameController.clear();
    _majorController.clear();
    _studentIdController.clear();
    _subjectController.clear();
    _creditController.clear();
    _gradeController.clear();
    _showFormDialog('เพิ่มข้อมูลเกรด');
  }

  Future<void> _showEditDialog(Map item) async {
    editingId = item['id'];
    _nameController.text = item['name'];
    _majorController.text = item['major'];
    _studentIdController.text = item['studentId'];
    _subjectController.text = item['subject'];
    _creditController.text = item['credit'].toString();
    _gradeController.text = item['grade'];
    _showFormDialog('แก้ไขข้อมูลเกรด');
  }

  Future<void> _showFormDialog(String title) async {
    return showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'ชื่อ-นามสกุล')),
              TextField(controller: _majorController, decoration: const InputDecoration(labelText: 'สาขา')),
              TextField(controller: _studentIdController, decoration: const InputDecoration(labelText: 'รหัสนักศึกษา')),
              TextField(controller: _subjectController, decoration: const InputDecoration(labelText: 'วิชา')),
              TextField(controller: _creditController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'หน่วยกิต')),
              TextField(controller: _gradeController, decoration: const InputDecoration(labelText: 'เกรด')),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (editingId == null) {
                addData();
              } else {
                updateData();
              }
              Navigator.pop(context);
            },
            child: const Text('ยืนยัน'),
          )
        ],
      ),
    );
  }

  Future<void> addData() async {
    Map<String, dynamic> data = {
      'name': _nameController.text,
      'major': _majorController.text,
      'studentId': _studentIdController.text,
      'subject': _subjectController.text,
      'credit': int.tryParse(_creditController.text) ?? 0,
      'grade': _gradeController.text,
    };

    var body = jsonEncode(data);
    await http.post(
      Uri.http('192.168.1.106:5000', 'create_grade'),
      headers: {"Content-Type": "application/json"},
      body: body,
    );
    fetchData();
  }

  Future<void> updateData() async {
    Map<String, dynamic> data = {
      'name': _nameController.text,
      'major': _majorController.text,
      'studentId': _studentIdController.text,
      'subject': _subjectController.text,
      'credit': int.tryParse(_creditController.text) ?? 0,
      'grade': _gradeController.text,
    };

    var body = jsonEncode(data);
    await http.put(
      Uri.http('192.168.1.106:5000', 'update_grade/$editingId'),
      headers: {"Content-Type": "application/json"},
      body: body,
    );
    fetchData();
  }

  Future<void> deleteData(int id) async {
    await http.delete(
      Uri.http('192.168.1.106:5000', 'delete_grade/$id'),
    );
    fetchData();
  }
}