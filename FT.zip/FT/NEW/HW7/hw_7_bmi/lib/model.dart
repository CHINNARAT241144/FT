class GradeModel {
  final String id;
  final String name;
  final String major;
  final String studentId;
  final String subject;
  final int credit;
  final String grade;

  GradeModel._({
    required this.id,
    required this.name,
    required this.major,
    required this.studentId,
    required this.subject,
    required this.credit,
    required this.grade,
  });

  factory GradeModel.fromJson(Map<String, dynamic> json) {
    return GradeModel._(
      id: json['id'],
      name: json['name'],
      major: json['major'],
      studentId: json['studentId'],
      subject: json['subject'],
      credit: json['credit'],
      grade: json['grade'],
    );
  }
}
