package com.example.hw_7_bmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
