# Updated server.py สำหรับระบบคำนวณเกรด พร้อมแสดงฟอร์ม HTML
from flask import Flask, request, jsonify, render_template
from flaskext.mysql import MySQL
import pymysql

app = Flask(__name__)
mysql = MySQL()

app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''
app.config['MYSQL_DATABASE_DB'] = 'grade_db'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)

@app.route('/')
def index():
    return """
    <h2>Grade Calculator API</h2>
    <a href='/grades'>ดูข้อมูลทั้งหมด</a><br>
    <a href='/new_grade'>เพิ่มข้อมูลเกรด (HTML Form)</a>
    """

@app.route('/new_grade')
def new_grade_form():
    return render_template('add.html')

@app.route('/grades', methods=['GET'])
def get_grades():
    try:
        conn = mysql.connect()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT * FROM grades")
        rows = cursor.fetchall()
        return jsonify(rows)
    except Exception as e:
        return jsonify({'error': str(e)})
    finally:
        cursor.close()
        conn.close()

@app.route('/create_grade', methods=['POST'])
def create_grade():
    try:
        data = request.json
        name = data['name']
        major = data['major']
        studentId = data['studentId']
        subject = data['subject']
        credit = data['credit']
        grade = data['grade']

        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "INSERT INTO grades (name, major, studentId, subject, credit, grade) VALUES (%s, %s, %s, %s, %s, %s)"
        cursor.execute(sql, (name, major, studentId, subject, credit, grade))
        conn.commit()
        return jsonify({'message': 'Grade added successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})
    finally:
        cursor.close()
        conn.close()

@app.route('/update_grade/<int:id>', methods=['PUT'])
def update_grade(id):
    try:
        data = request.json
        name = data['name']
        major = data['major']
        studentId = data['studentId']
        subject = data['subject']
        credit = data['credit']
        grade = data['grade']

        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "UPDATE grades SET name=%s, major=%s, studentId=%s, subject=%s, credit=%s, grade=%s WHERE id=%s"
        cursor.execute(sql, (name, major, studentId, subject, credit, grade, id))
        conn.commit()
        return jsonify({'message': 'Grade updated successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})
    finally:
        cursor.close()
        conn.close()

@app.route('/delete_grade/<int:id>', methods=['DELETE'])
def delete_grade(id):
    try:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "DELETE FROM grades WHERE id=%s"
        cursor.execute(sql, (id,))
        conn.commit()
        return jsonify({'message': 'Grade deleted successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(host='192.168.1.106', port=5000, debug=True)
